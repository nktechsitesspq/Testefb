package br.com.fndetails.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        web = WebView(this)
        web.setBackgroundColor(android.graphics.Color.rgb(8, 13, 22))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applyMobileLayout()
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                // Keep the FN DETAILS site inside the app; allow WhatsApp links to be handled by the site.
                return !(url.startsWith("https://detail-spark-now.lovable.app") || url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/"))
            }
        }
        setContentView(web)
        web.loadUrl("https://detail-spark-now.lovable.app/")
    }

    private fun applyMobileLayout() {
        val css = """
          (function(){
            if(document.getElementById('fn-app-mobile-fix')) return;
            const style=document.createElement('style'); style.id='fn-app-mobile-fix';
            style.textContent=`
              html,body{max-width:100%!important;overflow-x:hidden!important;background:#080d16!important}
              *{box-sizing:border-box}
              nav, [role=navigation], .desktop-nav, .nav-links, .navigation-links {display:none!important}
              main, section, header, footer {max-width:100%;}
              img,video{max-width:100%;}
              @media(max-width:700px){
                body{font-size:16px!important}
                h1{font-size:clamp(2rem,8vw,3.2rem)!important;line-height:1.02!important}
                .container, [class*=container], [class*=max-w-]{max-width:100%!important}
                [class*=grid]{grid-template-columns:minmax(0,1fr)!important}
                .fn-app-carousel{display:flex!important;flex-direction:row!important;gap:14px!important;overflow-x:auto!important;overflow-y:hidden!important;scroll-snap-type:x mandatory!important;padding:8px 22px 20px!important;scrollbar-width:none!important;-webkit-overflow-scrolling:touch!important}
                .fn-app-carousel::-webkit-scrollbar{display:none!important}
                .fn-app-carousel>*{flex:0 0 82vw!important;width:82vw!important;max-width:360px!important;scroll-snap-align:start!important}
                .fn-app-carousel img{width:100%!important;height:230px!important;object-fit:cover!important}
                a,button{max-width:100%}
              }
            `;
            document.head.appendChild(style);
            // Convert likely gallery grids to a swipeable row, without changing other page sections.
            const headings=[...document.querySelectorAll('h1,h2,h3')];
            const galleryHeading=headings.find(h=>/galeria|trabalhos|resultados|nosso trabalho/i.test(h.innerText||''));
            if(galleryHeading){
              let section=galleryHeading.closest('section')||galleryHeading.parentElement?.parentElement;
              if(section){
                const candidates=[...section.querySelectorAll('div')].filter(el=>el.children.length>=3 && [...el.children].every(ch=>ch.querySelector('img')));
                candidates.sort((a,b)=>b.children.length-a.children.length);
                if(candidates[0]) candidates[0].classList.add('fn-app-carousel');
              }
            }
          })();
        """.trimIndent()
        web.evaluateJavascript(css, null)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
